sap.ui.define([
	"ZSD_APP_GREMI/ZSD_APP_GREMI/test/unit/controller/App.controller"
], function () {
	"use strict";
});