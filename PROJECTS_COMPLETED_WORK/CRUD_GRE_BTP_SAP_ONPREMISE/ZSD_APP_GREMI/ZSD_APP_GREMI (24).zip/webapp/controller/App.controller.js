sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function (Controller,History) {
	"use strict";

	return Controller.extend("ZSD_APP_GREMI.ZSD_APP_GREMI.controller.App", {
		onInit: function () {

		}
	});
});